let popup = document.getElementById('loginModal');
let loginLink = document.getElementById('loginLink');
let closeBtn = document.getElementById('closeModal');
let form = document.getElementById('loginForm');
let title = document.getElementById('modalTitle');
let emailInput = document.getElementById('email');
let passwordInput = document.getElementById('password');
let confirmInput = document.getElementById('confirmPassword');
let confirmGroup = document.getElementById('confirmGroup');
let emailError = document.getElementById('emailError');
let passwordError = document.getElementById('passwordError');
let confirmError = document.getElementById('confirmError');
let successMsg = document.getElementById('loginSuccess');
let submitBtn = document.getElementById('submitBtn');
let switchText = document.getElementById('switchText');
let switchMode = document.getElementById('switchMode');

let breadFilterBtn = document.querySelectorAll('.breadFilter');
let cakeFilterBtn = document.querySelectorAll('.cakeFilter');
let pastryFilterBtn = document.querySelectorAll('.pastryFilter');
let allFilterBtn = document.querySelectorAll('.allFilter');

let savedEmail = '';
let savedPassword = '';
let loggedIn = false;
let mode = 'login';

function clearMessages() {
  emailError.textContent = '';
  passwordError.textContent = '';
  confirmError.textContent = '';
  successMsg.textContent = '';
}

function showLoginMode() {
  mode = 'login';
  clearMessages();
  form.reset();
  title.textContent = 'Login';
  submitBtn.textContent = 'Log In';
  confirmGroup.style.display = 'none';
  switchText.textContent = 'No account yet?';
  switchMode.textContent = 'Sign Up';
}

function showSignUpMode() {
  mode = 'signup';
  clearMessages();
  form.reset();
  title.textContent = 'Sign Up';
  submitBtn.textContent = 'Create Account';
  confirmGroup.style.display = 'block';
  switchText.textContent = 'Already have an account?';
  switchMode.textContent = 'Log In';
}

function closePopup() {
  popup.style.display = 'none';
  showLoginMode();
}

loginLink.addEventListener('click', function (e) {
  e.preventDefault();
  if (loggedIn === true) {
    loggedIn = false;
    loginLink.textContent = 'Login';
  } else {
    showLoginMode();
    popup.style.display = 'flex';
  }
});

switchMode.addEventListener('click', function (e) {
  e.preventDefault();
  if (mode === 'login') {
    showSignUpMode();
  } else {
    showLoginMode();
  }
});

closeBtn.addEventListener('click', function () {
  closePopup();
});

form.addEventListener('submit', function (e) {
  e.preventDefault();
  clearMessages();

  let email = emailInput.value.trim();
  let password = passwordInput.value;
  let confirm = confirmInput.value;
  let ok = true;

  if (email === '') {
    emailError.textContent = 'Email is required.';
    ok = false;
  } else if (email.includes('@') === false) {
    emailError.textContent = 'Email must contain @.';
    ok = false;
  } else if (email.includes('.') === false) {
    emailError.textContent = 'Email must contain a dot (.).';
    ok = false;
  }

  if (password === '') {
    passwordError.textContent = 'Password is required.';
    ok = false;
  } else if (password.length < 6) {
    passwordError.textContent = 'Password must be at least 6 characters.';
    ok = false;
  }

  if (mode === 'signup' && ok === true && password !== confirm) {
    confirmError.textContent = 'Passwords do not match.';
    ok = false;
  }

  if (ok === true) {
    if (mode === 'signup') {
      savedEmail = email;
      savedPassword = password;
      showLoginMode();
      successMsg.textContent = 'Account created! You can now log in.';
    } else {
      if (email !== savedEmail) {
        emailError.textContent = 'No account found. Please sign up first.';
      } else if (password !== savedPassword) {
        passwordError.textContent = 'Incorrect password.';
} else {
  loggedIn = true;
  successMsg.textContent = 'Login successful!';
  let name = email.split('@')[0];
  loginLink.textContent = 'Logout ' + name ;
  setTimeout(closePopup, 1200);
}
    }
  }
}); 

allFilterBtn.forEach(function(btn) {
    btn.addEventListener('click', function() {
        document.querySelectorAll(".breadType").forEach(element => {
          element.style.display = "";
      });

      document.querySelectorAll(".cakeType").forEach(element => {
          element.style.display = "";
      });

      document.querySelectorAll(".pastryType").forEach(element => {
          element.style.display = "";
      });
    });
});

breadFilterBtn.forEach(function(btn) {
    btn.addEventListener('click', function() {
        document.querySelectorAll(".breadTYpe").forEach(element => {
          element.style.display = "";
      });
      // $(".cakeType").show();

      document.querySelectorAll(".cakeType").forEach(element => {
          element.style.display = "none";
      });

      document.querySelectorAll(".pastryType").forEach(element => {
          element.style.display = "none";
      });
    });
});

cakeFilterBtn.forEach(function(btn) {
    btn.addEventListener('click', function() {
        document.querySelectorAll(".cakeType").forEach(element => {
          element.style.display = "";
      });

      document.querySelectorAll(".breadType").forEach(element => {
          element.style.display = "none";
      });

      document.querySelectorAll(".pastryType").forEach(element => {
          element.style.display = "none";
      });
    });
});

pastryFilterBtn.forEach(function(btn) {
    btn.addEventListener('click', function() {
        document.querySelectorAll(".pastryType").forEach(element => {
          element.style.display = "";
      });

      document.querySelectorAll(".breadType").forEach(element => {
          element.style.display = "none";
      });

      document.querySelectorAll(".cakeType").forEach(element => {
          element.style.display = "none";
      });
    });
});

 
let categoryButtons = document.querySelectorAll(".category-buttons button");

for (let i = 0; i < categoryButtons.length; i++) {
    categoryButtons[i].addEventListener("click", function () {
        for (let j = 0; j < categoryButtons.length; j++) {
            categoryButtons[j].classList.remove("active");
        }
        categoryButtons[i].classList.add("active");
    });
}

function addToCart(name, price) {
    let quantity = localStorage.getItem("cart_" + name);

    // Kung wala pa, magsimula sa 0
    if (quantity == null) {
        quantity = 0;
    }

    quantity = Number(quantity) + 1;

    localStorage.setItem("cart_" + name, quantity);
    localStorage.setItem("price_" + name, price);

    alert(name + " is added to cart!");
}

function showCart() {
    let html = "";
    let total = 0;

    for (let i = 0; i < localStorage.length; i++) {
        let key = localStorage.key(i);
        if (key.startsWith("cart_")) {
            let name = key.replace("cart_", "");
            let quantity = Number(localStorage.getItem(key));
            let price = Number(localStorage.getItem("price_" + name));
            let subtotal = price * quantity;

            total = total + subtotal;

           html = html + "<div class='cart-row'>" +
       "<span>" + name + "</span>" +
       "<span>₱" + price + "</span>" +
       "<span>" + quantity + "</span>" +
       "<span>₱" + subtotal + "</span>" +
       "<button class='remove-btn' onclick=\"removeItem('" + name + "')\">Remove</button>" +
       "</div>";
        }
    }
   if (html == "") {
    document.getElementById("cartItems").innerHTML = "Your cart is empty.";
    document.getElementById("cartTotal").innerHTML = "";
}
    else {
    let header = "<div class='cart-row cart-header'>" +
                 "<span>Product</span>" +
                 "<span>Price</span>" +
                 "<span>Quantity</span>" +
                 "<span>Total</span>" +
                 "<span></span>" +
                 "</div>";

    document.getElementById("cartItems").innerHTML = header + html;
    document.getElementById("cartTotal").innerHTML = "Total: ₱" + total;
}
}

function removeItem(name) {
    localStorage.removeItem("cart_" + name);
    localStorage.removeItem("price_" + name);
    showCart();
}

function checkout() {
    if (document.getElementById("cartTotal").innerHTML == "") {
        alert("Your cart is empty.");
        return;
    }

    for (let i = localStorage.length - 1; i >= 0; i--) {
        let key = localStorage.key(i);

        if (key.startsWith("cart_") || key.startsWith("price_")) {
            localStorage.removeItem(key);
        }
    }
    alert("Thank you! Your order has been placed.");
    showCart();
}
if (document.getElementById("cartItems") != null) {
    showCart();
}